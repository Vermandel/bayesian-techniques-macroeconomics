% Course: Bayesian Techniques in Macroeconomics (2026-2027)
% Instructor: Gauthier Vermandel
% Institution: Universite Paris-Dauphine PSL
%
%%% 
%%% New Classical Growth Model
%%% gauthier@vermandel.fr
%%% DSGE course @dauphine
%%% Solution by hand of the RBC model


% number of endogenous
endo_nbr = 3;
% number of exogenous
exo_nbr  = 1;
% number of simulations
Tsim	 = 200;

% Calibration
alpha		= 0.40;				% capital share in production 
beta    	= 0.99;				% discount factor
delta    	= 0.025;			% depreciation rate
rho_A		= 0.85;				% shock autocorrelation


% steady states
Kss			= ((1/beta-(1-delta))/alpha)^(1/(alpha-1));
Css			= Kss^alpha - delta*Kss;

% shock covariance
Q = .007^2;


%%% Solve the model
%% extract parameters
k1 = Kss^(alpha-1);
k2 = Kss^(alpha-1)*alpha+(1-delta);
k3 = Css/Kss;
c1 = beta*alpha*Kss^(alpha-1);
c2 = beta*alpha*Kss^(alpha-1)*(alpha-1);
%% Get closed-form solution of the form:
% x(t) = F*x(t-1) + G*e(t)
% 1) Compute matrix F:
% find roots of the equation - roots([A*x^2 B*x C])
Fcs = roots([-k3 (-1+k3*c2+k2) -k2*c2]);
% pick the stable one
Fc 	= Fcs((Fcs<1) & (Fcs>0));
Fk = k2 - k3*Fc;
% 2) Compute matrix G:
Gc = ((Fc-c2)*k1-c1*rho_A)/((Fc-c2)*k3+1-rho_A);
Gk = k1-k3*Gc;

% build model's matrices
% x = [ k, a, c]'
F = [ 	Fk,	Gk*rho_A,	0;
		0,	rho_A,		0;
		Fc,	Gc*rho_A,	0];
G = [ Gk;	1;	Gc];

%% Simulate the model
x_ = zeros(endo_nbr,Tsim+1);
e_ = randn(exo_nbr,Tsim)*chol(Q);
for t = 2:(Tsim+1)
	x_(:,t) = F*x_(:,t-1)+G*e_(t-1);
end
% remove initial period of all zeros
x_ = x_(:,2:end);


% let us assume that we only observe consumption
% selection matrix pick third variables of x:
H = [0 0 1];
% that satisfies:
y_obs = H *x_;

%% Apply inversion filter
x_hat = zeros(endo_nbr,Tsim+1);
e_hat = zeros(exo_nbr,Tsim+1);
for t = 2:(Tsim+1)
	% invert the model
	e_hat(:,t) = (H*G)\(y_obs(:,t-1)-H*F*x_hat(:,t-1));
	% feed the model with new shock
	x_hat(:,t) = F*x_hat(:,t-1)+G*e_hat(:,t);
end
% remove initial period
e_hat = e_hat(:,2:end);
x_hat = x_hat(:,2:end);

% compare
figure;
subplot(1,2,1)
plot(1:Tsim,e_hat,1:Tsim,e_,'o')
title('Shocks')
legend('Filtered','True')
subplot(1,2,2)
plot(1:Tsim,H*x_hat,1:Tsim,H*x_,'o')
title('Observable (c_{t})')
legend('Smoothed','True')



% Suppose now that we want to estimate 
% the covariance of error Sige

T = length(e_hat);
% The likelihood function reads as follows:
llk = @(x) -( -T/2*log(2*pi*x(1))  -1/(2*x(1))*(e_hat*e_hat'));

% Maximum likelihood estimation
% use fmincon to estimate theta
theta0 = 0.01; % initial guess e
theta_MLE = fmincon(llk,theta0,[],[],[],[],1e-8);
disp(['Estimated standard deviation of errors is ' num2str(sqrt(theta_MLE))])



